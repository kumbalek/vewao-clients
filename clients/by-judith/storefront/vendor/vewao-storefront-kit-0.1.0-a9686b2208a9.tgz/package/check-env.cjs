/**
 * The build-time half of the env guard.
 *
 * `next.config.js` is CommonJS and runs before anything in `src/` is compiled,
 * so this cannot import `src/env.ts`. The variable names are therefore repeated
 * here on purpose — two strings, in exchange for a storefront that fails to
 * build rather than failing on a customer's first request.
 *
 * `src/env.ts` is the runtime half and carries the fuller explanation.
 */
const REQUIRED = [
  ["NEXT_PUBLIC_MEDUSA_BACKEND_URL", "The client's Medusa instance, e.g. https://api.shop.cz"],
  ["NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY", "Created per sales channel in the Medusa admin"],
]

module.exports = function checkStorefrontEnv(env = process.env) {
  const missing = REQUIRED.filter(([key]) => !env[key] || String(env[key]).trim() === "")
  if (missing.length === 0) return

  const lines = missing.map(([key, hint]) => `  ${key}\n    ${hint}`).join("\n")
  throw new Error(
    `Storefront environment is incomplete. Missing:\n${lines}\n\n` +
      "These are rendered from the client's instance.yaml at deploy time."
  )
}
