# @vewao/storefront-kit

Useful shared storefront helpers for the first client MVP. Reuse them where they
help deliver the shop. The kit is partial; it is not a requirement to build a
universal checkout, theme or sealed-component framework before the client UI.

```
src/env.ts          required environment values
src/client.ts       Medusa SDK setup
src/query-keys.ts   cache keys
src/format.ts       money and date formatting
src/theme/          existing token-to-CSS helpers
src/checkout/       payment-provider and cart-completion helpers
src/consent.ts      consent record, cookie serialisation and parsing
src/components/     accessible primitives, incl. the cookie-consent banner
src/sealed.ts       existing slot definitions, not completed compliance components
```

## Consumption

The package exposes TypeScript source, compiled by the consumer's Next build:

```js
// next.config.js
module.exports = { transpilePackages: ["@vewao/storefront-kit"] }
```

Use a published version when available, or a documented local package/pack
workflow while registry publishing is deferred. Record the source revision and
make production builds reproducible. Workspace consumption inside the platform
is supported. Do not copy and patch the kit into a client repository.

The client owns its pages, forms and flow composition. Extract shared logic here
when that improves correctness or reduces duplication. Existing compliance slots
are optional scaffolding, not a required API; implement applicable product/legal
information in the real flow and preserve its correctness when styling it.

## Integration details

Treat Medusa v2 prices as decimal amounts; do not divide storefront amounts by
100. Prefer the SDK helpers, which handle the publishable API key. Custom store
requests must supply the required authentication/configuration themselves.

Current cart-completion helpers distinguish redirects from completion. Their
unit tests do not establish that a real payment callback settles a payment or
creates an order; verify the full backend and storefront integration before use.

## Cookie consent

`CookieConsent` renders a non-modal banner until the shopper decides. It is
non-modal deliberately: the page behind it stays usable and nothing steals
focus on first load. "Reject all" is the same element with the same styling as
"Accept all"; "Customize" reveals one checkbox per category, all unchecked by
default, and a "Save" button.

Props:

- `version` — bump it to invalidate every stored decision and re-ask.
- `maxAgeDays` — decision lifetime, default 180.
- `categories` — `{ id, label, description }` per optional category.
- `copy` — every visible string; the kit hardcodes no shop text.
- `policyHref` / `policyLabel` — link to the client's cookie policy page.
- `onChange` — called with the record when a decision is stored.

Two `window` events, named in `src/consent.ts`:

- `vw:consent-change` — fired with the new record whenever a decision is
  stored; `useConsent` listens to it. Same-document only.
- `vw:consent-open` — dispatch it with `openCookieSettings()` (e.g. from a
  privacy settings link) and the banner reopens with customize open and the
  current choices pre-filled, focus on the heading. After a decision made in a
  reopened banner, focus returns to the element that opened it.

`useConsent({ version, maxAgeDays? })` returns the stored record (null before
mount and when nothing valid is stored). `ConsentGate` requires the same
`version` and renders its children only when the record grants the category —
an analytics script goes inside it and does not exist on the page before
consent. Bumping `version` invalidates every stored decision, so the banner
re-asks and every gate unmounts.

Withdrawing consent unmounts gated children, but it cannot unload a script
that already executed or delete cookies a third party already set. When a
previously granted category is revoked, have the page reload in `onChange`.

Necessary cookies need no consent and are not a category. The legal copy, the
category set and the policy page are the client's responsibility.

## Testing

The unit tests cover env/format/theme, payment/completion helpers and consent
logic.
End-to-end checkout and rendered-page accessibility still need verification as
the actual shop is built. Add tests for concrete critical flows and shared logic.
