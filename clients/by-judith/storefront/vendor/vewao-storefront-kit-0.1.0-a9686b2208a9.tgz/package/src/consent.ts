/**
 * Cookie consent as data: the record, its cookie form, and the questions
 * asked about it.
 *
 * Three rules shape this module:
 *
 * - A cookie is attacker-controlled input. `parseConsent` therefore returns
 *   null ("ask again") instead of throwing — a malformed value must degrade
 *   into the banner, never into a crashed page.
 * - `version` on the record is the client's escape hatch: bump the version
 *   and every stored decision silently becomes "no decision", because
 *   consent given for an old policy is not consent for the new one.
 * - Necessary cookies need no consent, so they are not a category. Absence
 *   of the cookie must never block the shop's own functioning.
 *
 * No React and no DOM access at import time — the module is importable from
 * server code and from tests. It does accept the URI-encoded cookie form,
 * because that is what `document.cookie` hands back after the banner writes
 * a record.
 */

export type ConsentCategory = "analytics" | "marketing"

export type ConsentRecord = {
  /** The consent configuration the decision was made under. */
  version: number
  /** ISO timestamp of the decision. */
  decidedAt: string
  /** Categories the shopper granted. Necessary cookies are not listed. */
  granted: ConsentCategory[]
}

export const CONSENT_COOKIE = "vw_consent"

/** How long a consent decision lasts, when the client does not say otherwise. */
export const DEFAULT_CONSENT_MAX_AGE_DAYS = 180

/** Fired on `window` with the new record whenever a decision is stored. */
export const CONSENT_CHANGE_EVENT = "vw:consent-change"
/** Fired on `window` to ask the banner to reopen, e.g. from a settings link. */
export const CONSENT_OPEN_EVENT = "vw:consent-open"

export function serializeConsent(record: ConsentRecord): string {
  return JSON.stringify(record)
}

export type ParseConsentOptions = {
  /** The version the client currently asks under; anything else is stale. */
  version: number
  /** Decisions older than this are treated as never given. */
  maxAgeDays: number
  now?: Date
}

/**
 * Read a stored record, or null when the shopper must be asked again.
 *
 * Accepts both the bare serialized form and the URI-encoded cookie form.
 * Null means missing, malformed, wrong-shaped, unknown-category, other-
 * version, invalid-date or expired — it never means "throw".
 */
export function parseConsent(raw: string | undefined, opts: ParseConsentOptions): ConsentRecord | null {
  if (raw === undefined) return null

  let text = raw
  try {
    text = decodeURIComponent(raw)
  } catch {
    // Not URI-encoded; parse it as it stands.
  }

  let value: unknown
  try {
    value = JSON.parse(text)
  } catch {
    return null
  }

  if (typeof value !== "object" || value === null || Array.isArray(value)) return null
  const { version, decidedAt, granted } = value as {
    version?: unknown
    decidedAt?: unknown
    granted?: unknown
  }

  if (typeof version !== "number" || !Number.isFinite(version)) return null
  if (typeof decidedAt !== "string" || Number.isNaN(new Date(decidedAt).getTime())) return null
  if (!Array.isArray(granted)) return null

  for (const entry of granted) {
    if (entry !== "analytics" && entry !== "marketing") return null
  }

  if (version !== opts.version) return null
  const maxAgeMs = opts.maxAgeDays * 24 * 60 * 60 * 1000
  const decided = new Date(decidedAt)
  // Exactly maxAgeDays old still counts; only older is expired. The cookie's
  // own Max-Age usually deletes it first — this is the second line of defence.
  if ((opts.now ?? new Date()).getTime() - decided.getTime() > maxAgeMs) return null

  return {
    version,
    decidedAt,
    granted: granted.filter((entry): entry is ConsentCategory => entry === "analytics" || entry === "marketing"),
  }
}

/** False when there is no record: no consent means no script, not the opposite. */
export function hasConsent(record: ConsentRecord | null, category: ConsentCategory): boolean {
  return record !== null && record.granted.includes(category)
}

export type ConsentCookieOptions = {
  maxAgeDays: number
  secure?: boolean
}

/** The attributes every consent cookie is written with — Lax, not None. */
export function consentCookieAttributes({ maxAgeDays, secure }: ConsentCookieOptions): string {
  const attributes = `Path=/; Max-Age=${maxAgeDays * 24 * 60 * 60}; SameSite=Lax`
  return secure ? `${attributes}; Secure` : attributes
}
