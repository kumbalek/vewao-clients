/**
 * Fail the build, not the checkout.
 *
 * Carried forward from the legacy storefront's `check-env-variables.js`, which
 * was the one piece of that app's tooling worth keeping: a missing backend URL
 * or publishable key produces a shop that builds, deploys, and then fails on
 * the first request a customer makes. Better it never builds.
 */

export type StorefrontEnv = {
  backendUrl: string
  publishableKey: string
  defaultRegion: string
  storefrontUrl?: string
}

const REQUIRED: { key: string; hint: string }[] = [
  {
    key: "NEXT_PUBLIC_MEDUSA_BACKEND_URL",
    hint: "The client's Medusa instance, e.g. https://api.shop.cz. Rendered from instance.yaml at deploy time.",
  },
  {
    key: "NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY",
    hint: "Created per sales channel in the Medusa admin. Store routes reject requests without it.",
  },
]

export function readStorefrontEnv(source: Record<string, string | undefined> = process.env): StorefrontEnv {
  const missing = REQUIRED.filter(({ key }) => {
    const value = source[key]
    return value === undefined || value.trim() === ""
  })

  if (missing.length > 0) {
    const lines = missing.map(({ key, hint }) => `  ${key}\n    ${hint}`)
    throw new Error(
      `Storefront environment is incomplete. Missing:\n${lines.join("\n")}\n\n` +
        "These are rendered from the client's instance.yaml during deploy. A storefront that " +
        "builds without them fails on the first customer request instead."
    )
  }

  return {
    backendUrl: source["NEXT_PUBLIC_MEDUSA_BACKEND_URL"]!.replace(/\/+$/, ""),
    publishableKey: source["NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY"]!,
    defaultRegion: source["NEXT_PUBLIC_DEFAULT_REGION"] ?? "cz",
    storefrontUrl: source["NEXT_PUBLIC_STOREFRONT_URL"],
  }
}
