/**
 * The one place the SDK is instantiated.
 *
 * Every request to Medusa goes through this client, never through `fetch`.
 * Store routes reject a request without the publishable API key, and the SDK
 * is what attaches it — a bare `fetch` fails in a way that looks like a server
 * problem and is not.
 *
 * `@medusajs/js-sdk` has no Medusa runtime dependencies, so this is safe to
 * import from a server component as well as from the browser.
 */
import Medusa from "@medusajs/js-sdk"

import { readStorefrontEnv, type StorefrontEnv } from "./env"

export type StorefrontClient = Medusa

let cached: { client: Medusa; key: string } | undefined

export function createStorefrontClient(env: StorefrontEnv = readStorefrontEnv()): Medusa {
  // One instance per (url, key) pair. Next re-imports modules across route
  // segments; a new SDK per import would discard connection reuse for nothing.
  const key = `${env.backendUrl}::${env.publishableKey}`
  if (cached?.key === key) return cached.client

  const client = new Medusa({
    baseUrl: env.backendUrl,
    publishableKey: env.publishableKey,
    debug: process.env["NODE_ENV"] === "development",
  })

  cached = { client, key }
  return client
}
