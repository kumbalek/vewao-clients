export { readStorefrontEnv } from "./env"
export type { StorefrontEnv } from "./env"

export { createStorefrontClient } from "./client"
export type { StorefrontClient } from "./client"

export { keys } from "./query-keys"

export { formatMoney, formatDate, discountPercentage } from "./format"
export type { MoneyInput } from "./format"

export {
  CONSENT_COOKIE,
  CONSENT_CHANGE_EVENT,
  CONSENT_OPEN_EVENT,
  DEFAULT_CONSENT_MAX_AGE_DAYS,
  serializeConsent,
  parseConsent,
  hasConsent,
  consentCookieAttributes,
} from "./consent"
export type { ConsentCategory, ConsentRecord, ParseConsentOptions } from "./consent"

export { COMPLIANCE_SLOTS } from "./sealed"
export type { ComplianceSlot, SealedProps } from "./sealed"

export * from "./theme/index"
export * from "./checkout/index"
export * from "./components/index"
