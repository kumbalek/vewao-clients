/**
 * Hierarchical query keys, so a cache invalidation can be as coarse or as
 * precise as the mutation that caused it.
 *
 * `invalidateQueries({ queryKey: keys.cart() })` after a line-item change
 * catches every cart-derived query; `keys.product(handle)` catches one product.
 * Flat keys make the first of those impossible and it is the one that is
 * needed most.
 */
export const keys = {
  all: ["vewao"] as const,

  regions: () => [...keys.all, "regions"] as const,
  region: (id: string) => [...keys.regions(), id] as const,

  products: () => [...keys.all, "products"] as const,
  productList: (params: Record<string, unknown>) => [...keys.products(), "list", params] as const,
  product: (handle: string) => [...keys.products(), "detail", handle] as const,
  priceHistory: (productId: string) => [...keys.product(productId), "price-history"] as const,

  categories: () => [...keys.all, "categories"] as const,
  category: (handle: string) => [...keys.categories(), handle] as const,

  cart: () => [...keys.all, "cart"] as const,
  cartById: (id: string) => [...keys.cart(), id] as const,
  shippingOptions: (cartId: string) => [...keys.cartById(cartId), "shipping-options"] as const,
  paymentProviders: (regionId: string) => [...keys.all, "payment-providers", regionId] as const,

  customer: () => [...keys.all, "customer"] as const,
  orders: () => [...keys.customer(), "orders"] as const,
  order: (id: string) => [...keys.orders(), id] as const,
} as const
