/**
 * Sealed components — the mechanism behind the storefront split.
 *
 * A client storefront owns its layout, styling and copy. It does not own what
 * a compliance component renders. If each of thirty storefronts could change
 * how an Omnibus reference price is displayed, a change in the law becomes
 * thirty projects, and version discipline is broken through the back door.
 *
 * So compliance components take **no override props**: no `render`, no
 * `children` that replace content, no `className` that could hide a required
 * element. They take data and a slot position. They style themselves from the
 * theme tokens, which is where a client's freedom lives.
 *
 * This module is the contract, not a framework. The enforcement is that the
 * components simply do not accept the props — there is nothing to argue about
 * in review.
 */

/**
 * Where in a page a sealed compliance component renders. A client storefront
 * places the slot; it does not decide what fills it.
 *
 * The components themselves land in Phase 2 (C1–C9). The positions exist now
 * because a storefront built without them has to be re-laid-out later, and
 * "we will add the compliance block afterwards" is how it ends up in a footer
 * nobody reads.
 */
export type ComplianceSlot =
  /** Omnibus reference price, beside any discounted price (C1). */
  | "product.price"
  /** GPSR manufacturer, EU responsible person, warnings (C2). */
  | "product.safety"
  /** Verified/unverified review labelling (C4). */
  | "product.reviews"
  /** Cookie consent, Consent Mode v2 (C5). */
  | "layout.consent"
  /** DSA contact point and reporting mechanism (C3). */
  | "layout.legal"
  /** The electronic withdrawal function (C7). */
  | "account.withdrawal"
  /** Price and total breakdown, including the VAT statement (C9). */
  | "checkout.summary"

export const COMPLIANCE_SLOTS: ComplianceSlot[] = [
  "product.price",
  "product.safety",
  "product.reviews",
  "layout.consent",
  "layout.legal",
  "account.withdrawal",
  "checkout.summary",
]

/**
 * Props a sealed component may accept. Deliberately narrow: data, and a test
 * id so end-to-end tests can assert the block is present — which is how the
 * kit proves compliance renders, rather than trusting that it does.
 */
export type SealedProps<TData> = {
  data: TData
  "data-testid"?: string
}
