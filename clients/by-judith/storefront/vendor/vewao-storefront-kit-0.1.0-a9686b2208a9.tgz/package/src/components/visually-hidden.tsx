/**
 * Text for screen readers only.
 *
 * `display: none` and `visibility: hidden` remove content from the
 * accessibility tree as well as the page — this is the clip-rect technique that
 * does not. Used for things like "opens in a new window" and the label of an
 * icon-only button, both of which appear in every storefront.
 */
import * as React from "react"

export function VisuallyHidden({ children }: { children: React.ReactNode }): React.ReactElement {
  return (
    <span
      style={{
        position: "absolute",
        width: "1px",
        height: "1px",
        margin: "-1px",
        padding: 0,
        overflow: "hidden",
        clip: "rect(0, 0, 0, 0)",
        whiteSpace: "nowrap",
        border: 0,
      }}
    >
      {children}
    </span>
  )
}
