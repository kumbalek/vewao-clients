"use client"

/**
 * A labelled form field with its error wired up.
 *
 * Checkout is where accessibility failures cost orders rather than points. The
 * three things this exists to make impossible:
 *
 * - an input with no programmatic label (a placeholder is not a label)
 * - an error message that is visually adjacent but not announced
 * - an invalid field that is not marked `aria-invalid`
 *
 * The ids are generated with `useId` so a field can appear more than once on a
 * page — a billing address beside a shipping address, which is exactly where
 * duplicate ids get shipped.
 *
 * `"use client"` because of that hook, and for no other reason. The directive
 * survives publication because the kit ships as source and each client's Next
 * build compiles it (D18) — bundling this package is where those boundaries
 * would silently break.
 */
import * as React from "react"

import { token } from "../theme/tokens"

export type FieldProps = {
  label: string
  /** Rendered as help text and referenced by aria-describedby. */
  hint?: string
  error?: string
  required?: boolean
  children: (props: {
    id: string
    "aria-describedby": string | undefined
    "aria-invalid": boolean | undefined
    "aria-required": boolean | undefined
  }) => React.ReactNode
}

export function Field({ label, hint, error, required, children }: FieldProps): React.ReactElement {
  const generated = React.useId()
  const id = `field-${generated}`
  const hintId = hint ? `${id}-hint` : undefined
  const errorId = error ? `${id}-error` : undefined
  const describedBy = [hintId, errorId].filter(Boolean).join(" ") || undefined

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}>
      <label htmlFor={id} style={{ color: token("color-text") }}>
        {label}
        {required ? <span aria-hidden="true"> *</span> : null}
      </label>

      {children({
        id,
        "aria-describedby": describedBy,
        "aria-invalid": error ? true : undefined,
        "aria-required": required ? true : undefined,
      })}

      {hint ? (
        <span id={hintId} style={{ color: token("color-text-muted"), fontSize: "0.875em" }}>
          {hint}
        </span>
      ) : null}

      {error ? (
        // Announced when it appears, without moving focus away from the field
        // the shopper is still correcting.
        <span id={errorId} role="alert" style={{ color: token("color-danger") }}>
          {error}
        </span>
      ) : null}
    </div>
  )
}
