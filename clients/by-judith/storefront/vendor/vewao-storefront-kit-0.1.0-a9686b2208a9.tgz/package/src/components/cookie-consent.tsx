"use client"

/**
 * The consent banner, the hook that reads the decision, and the gate that
 * turns the decision into "which scripts may run".
 *
 * Why the banner is non-modal: it must not trap the shopper inside itself. A
 * page that blocks its own browsing until "Accept" is clicked trains every
 * visitor to hit the fastest button, and a choice made under that pressure is
 * not an informed one. It is a `region` anchored to the viewport; the page
 * behind it stays usable and nothing steals focus on first load.
 *
 * Why the banner ships no copy: consent is a legal statement, not UI
 * boilerplate. What the categories mean, what the policy page says, and in
 * which language — that is the client's responsibility. The kit guarantees
 * only that the choice is recorded, revocable, and equally weighted:
 * "Reject all" is the same element with the same styling as "Accept all",
 * because an equally easy way to refuse is the whole point of the component.
 *
 * Scripts that need consent load through `ConsentGate`, which renders its
 * children only when the stored record grants the category — an analytics
 * snippet placed inside it simply does not exist on the page before consent.
 */
import * as React from "react"

import {
  CONSENT_CHANGE_EVENT,
  CONSENT_COOKIE,
  CONSENT_OPEN_EVENT,
  DEFAULT_CONSENT_MAX_AGE_DAYS,
  consentCookieAttributes,
  hasConsent,
  parseConsent,
  serializeConsent,
} from "../consent"
import type { ConsentCategory, ConsentRecord } from "../consent"

export type ConsentCopy = {
  title: string
  body: string
  acceptAll: string
  rejectAll: string
  customize: string
  save: string
}

export type ConsentCategoryOption = {
  id: ConsentCategory
  label: string
  description: string
}

export type CookieConsentProps = {
  /**
   * The consent configuration this banner asks under. Bump it to invalidate
   * every stored decision and make the banner reappear.
   */
  version: number
  /** How long a decision lasts, in days. Default {@link DEFAULT_CONSENT_MAX_AGE_DAYS}. */
  maxAgeDays?: number
  categories: ConsentCategoryOption[]
  /** Every visible string. The kit hardcodes none of it. */
  copy: ConsentCopy
  policyHref: string
  policyLabel: string
  onChange?: (record: ConsentRecord) => void
}

const CLASS = "vw-cookie-consent"

const CSS = `
.${CLASS} {
  position: fixed;
  left: 50%;
  bottom: 1rem;
  transform: translateX(-50%);
  z-index: 1000;
  width: min(42rem, calc(100vw - 2rem));
  max-height: calc(100vh - 2rem);
  overflow-y: auto;
  padding: 1.25rem;
  background: var(--vw-color-surface);
  color: var(--vw-color-text);
  border: 1px solid var(--vw-color-border);
  border-radius: var(--vw-radius-lg);
  box-shadow: 0 8px 24px rgb(0 0 0 / 0.15);
  font-family: var(--vw-font-body);
}
.${CLASS}__title {
  margin: 0 0 0.375rem;
  font-size: 1rem;
  font-weight: 700;
}
.${CLASS}__body {
  margin: 0 0 0.75rem;
}
.${CLASS}__link {
  display: inline-block;
  margin-bottom: 0.875rem;
  color: var(--vw-color-primary);
  text-decoration: underline;
}
.${CLASS}__actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  align-items: center;
}
.${CLASS}__button {
  padding: 0.55rem 1.1rem;
  border: 1px solid var(--vw-color-primary);
  border-radius: var(--vw-radius-md);
  background: var(--vw-color-primary);
  color: var(--vw-color-on-primary);
  font: inherit;
  font-weight: 600;
  cursor: pointer;
}
.${CLASS}__button--ghost {
  background: transparent;
  border-color: var(--vw-color-border);
  color: var(--vw-color-text);
  font-weight: 400;
}
.${CLASS}__options {
  margin-top: 1rem;
  padding-top: 0.75rem;
  border-top: 1px solid var(--vw-color-border);
}
.${CLASS}__option {
  display: grid;
  grid-template-columns: auto 1fr;
  column-gap: 0.5rem;
  row-gap: 0.125rem;
  align-items: start;
  padding: 0.375rem 0;
}
.${CLASS}__option input[type="checkbox"] {
  margin-top: 0.2rem;
  accent-color: var(--vw-color-primary);
}
.${CLASS}__description {
  grid-column: 2;
  color: var(--vw-color-text-muted);
  font-size: 0.875em;
}
.${CLASS} a:focus-visible,
.${CLASS} button:focus-visible,
.${CLASS} input:focus-visible {
  outline: 3px solid var(--vw-color-focus);
  outline-offset: 2px;
}
`

/** The raw cookie value, still URI-encoded — parsing handles the decoding. */
function readCookie(name: string): string | undefined {
  if (typeof document === "undefined") return undefined
  const prefix = `${name}=`
  const entry = document.cookie.split("; ").find((cookie) => cookie.startsWith(prefix))
  return entry ? entry.slice(prefix.length) : undefined
}

function choicesFromRecord(
  record: ConsentRecord | null,
  categories: ConsentCategoryOption[]
): Record<ConsentCategory, boolean> {
  const choices: Record<ConsentCategory, boolean> = { analytics: false, marketing: false }
  for (const category of categories) {
    choices[category.id] = record !== null && record.granted.includes(category.id)
  }
  return choices
}

export function CookieConsent({
  version,
  maxAgeDays = DEFAULT_CONSENT_MAX_AGE_DAYS,
  categories,
  copy,
  policyHref,
  policyLabel,
  onChange,
}: CookieConsentProps): React.ReactElement | null {
  const generatedId = React.useId()
  const baseId = `${CLASS}-${generatedId}`
  const titleId = `${baseId}-title`
  const optionsId = `${baseId}-options`
  const headingRef = React.useRef<HTMLHeadingElement | null>(null)

  const [mounted, setMounted] = React.useState(false)
  const [visible, setVisible] = React.useState(false)
  const [customizing, setCustomizing] = React.useState(false)
  const [choices, setChoices] = React.useState<Record<ConsentCategory, boolean>>({
    analytics: false,
    marketing: false,
  })
  const [awaitingFocus, setAwaitingFocus] = React.useState(false)
  // Where focus came from when the banner was reopened via openCookieSettings
  // — the element a decision should be returned to. Null on the first-load
  // banner, whose decision must not move focus the user never placed.
  const restoreFocusRef = React.useRef<HTMLElement | null>(null)

  const readStoredRecord = React.useCallback((): ConsentRecord | null => {
    return parseConsent(readCookie(CONSENT_COOKIE), { version, maxAgeDays, now: new Date() })
  }, [version, maxAgeDays])

  const writeConsent = React.useCallback(
    (granted: ConsentCategory[]) => {
      const record: ConsentRecord = { version, decidedAt: new Date().toISOString(), granted }
      document.cookie = `${CONSENT_COOKIE}=${encodeURIComponent(
        serializeConsent(record)
      )}; ${consentCookieAttributes({ maxAgeDays, secure: window.location.protocol === "https:" })}`
      onChange?.(record)
      window.dispatchEvent(new CustomEvent(CONSENT_CHANGE_EVENT, { detail: record }))
      setVisible(false)
      setCustomizing(false)
      const toRestore = restoreFocusRef.current
      restoreFocusRef.current = null
      // Focus was somewhere specific before the reopened banner appeared;
      // leaving it on the now-removed banner is how focus ends up on <body>.
      const disabled = toRestore !== null && "disabled" in toRestore && Boolean(toRestore.disabled)
      if (toRestore && toRestore.isConnected && !disabled) {
        toRestore.focus()
      }
    },
    [version, maxAgeDays, onChange]
  )

  // Nothing renders — and no cookie is read — before hydration, so the server
  // HTML and the first client render agree.
  React.useEffect(() => {
    setMounted(true)
    setVisible(readStoredRecord() === null)
  }, [readStoredRecord])

  // Reopening (privacy settings link) is the one case that moves focus: the
  // user asked for it, so the heading must announce where they landed.
  React.useEffect(() => {
    const open = () => {
      restoreFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null
      setChoices(choicesFromRecord(readStoredRecord(), categories))
      setCustomizing(true)
      setVisible(true)
      setAwaitingFocus(true)
    }
    window.addEventListener(CONSENT_OPEN_EVENT, open)
    return () => window.removeEventListener(CONSENT_OPEN_EVENT, open)
  }, [readStoredRecord, categories])

  React.useEffect(() => {
    if (!awaitingFocus) return
    headingRef.current?.focus()
    setAwaitingFocus(false)
  }, [awaitingFocus])

  if (!mounted || !visible) return null

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />
      <section role="region" aria-labelledby={titleId} className={CLASS}>
        <h2 id={titleId} ref={headingRef} tabIndex={-1} className={`${CLASS}__title`}>
          {copy.title}
        </h2>
        <p className={`${CLASS}__body`}>{copy.body}</p>
        <a href={policyHref} className={`${CLASS}__link`}>
          {policyLabel}
        </a>

        <div className={`${CLASS}__actions`}>
          <button type="button" className={`${CLASS}__button`} onClick={() => writeConsent([])}>
            {copy.rejectAll}
          </button>
          <button type="button" className={`${CLASS}__button`} onClick={() => writeConsent(categories.map((c) => c.id))}>
            {copy.acceptAll}
          </button>
          <button
            type="button"
            className={`${CLASS}__button ${CLASS}__button--ghost`}
            aria-expanded={customizing}
            aria-controls={customizing ? optionsId : undefined}
            onClick={() => setCustomizing((open) => !open)}
          >
            {copy.customize}
          </button>
        </div>

        {customizing ? (
          <div id={optionsId} className={`${CLASS}__options`}>
            {categories.map((category) => {
              const fieldId = `${baseId}-${category.id}`
              const descriptionId = `${fieldId}-description`
              return (
                <div key={category.id} className={`${CLASS}__option`}>
                  <input
                    type="checkbox"
                    id={fieldId}
                    checked={choices[category.id]}
                    onChange={(event) => {
                      // Read now: React runs the updater later, when
                      // currentTarget is already null.
                      const checked = event.currentTarget.checked
                      setChoices((current) => ({ ...current, [category.id]: checked }))
                    }}
                    aria-describedby={descriptionId}
                  />
                  <label htmlFor={fieldId}>{category.label}</label>
                  <span id={descriptionId} className={`${CLASS}__description`}>
                    {category.description}
                  </span>
                </div>
              )
            })}
            <div className={`${CLASS}__actions`}>
              <button
                type="button"
                className={`${CLASS}__button`}
                onClick={() => writeConsent(categories.filter((category) => choices[category.id]).map((category) => category.id))}
              >
                {copy.save}
              </button>
            </div>
          </div>
        ) : null}
      </section>
    </>
  )
}

export type UseConsentOptions = {
  /**
   * The consent configuration the reader asks under, matching the banner's
   * `version`. A record under any other version, or older than `maxAgeDays`,
   * counts as no consent — bumping the version therefore revokes every gate,
   * which is the point.
   */
  version: number
  /** Decision lifetime in days; default {@link DEFAULT_CONSENT_MAX_AGE_DAYS}. */
  maxAgeDays?: number
}

/**
 * The stored record, null before mount and null when nothing valid is stored.
 *
 * Validates through the strict `parseConsent` — a stale or other-version
 * record is no consent, not a consent of an older kind.
 *
 * Updates whenever a decision is stored in this document via
 * `vw:consent-change`. A CustomEvent on `window` does not cross tabs.
 */
export function useConsent(options: UseConsentOptions): ConsentRecord | null {
  const { version, maxAgeDays = DEFAULT_CONSENT_MAX_AGE_DAYS } = options
  const [record, setRecord] = React.useState<ConsentRecord | null>(null)

  React.useEffect(() => {
    const update = () => {
      setRecord(parseConsent(readCookie(CONSENT_COOKIE), { version, maxAgeDays, now: new Date() }))
    }
    update()
    window.addEventListener(CONSENT_CHANGE_EVENT, update)
    return () => window.removeEventListener(CONSENT_CHANGE_EVENT, update)
  }, [version, maxAgeDays])

  return record
}

export type ConsentGateProps = {
  category: ConsentCategory
  /**
   * The consent configuration this gate asks under, matching the banner's
   * `version` — required, so a bumped version unmounts every gate.
   */
  version: number
  /** Decision lifetime in days; default {@link DEFAULT_CONSENT_MAX_AGE_DAYS}. */
  maxAgeDays?: number
  children: React.ReactNode
}

/**
 * Renders children only when the stored record grants the category. This is
 * how a client loads analytics: the script tag goes inside the gate and does
 * not exist on the page before consent.
 */
export function ConsentGate({
  category,
  version,
  maxAgeDays,
  children,
}: ConsentGateProps): React.ReactElement | null {
  const record = useConsent({ version, maxAgeDays })
  if (record === null) return null
  return hasConsent(record, category) ? <>{children}</> : null
}

/** Ask the banner to reopen with customize open — e.g. a privacy settings link. */
export function openCookieSettings(): void {
  if (typeof window === "undefined") return
  window.dispatchEvent(new CustomEvent(CONSENT_OPEN_EVENT))
}
