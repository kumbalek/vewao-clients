/**
 * The first element on every page, and the one most often missing.
 *
 * WCAG 2.4.1 (Bypass Blocks) is level A — below the AA floor the theme system
 * targets, which means a shop failing it fails the easy part. It lives in the
 * kit rather than in each storefront because thirty storefronts is thirty
 * chances to forget.
 *
 * Deliberately CSS-only: no focus handlers, no `"use client"`, no JavaScript in
 * the browser. An accessibility affordance that depends on a hydrated bundle is
 * an affordance that is missing for the first second of every page load, which
 * is exactly when a keyboard user reaches for it.
 */
import * as React from "react"

export type SkipLinkProps = {
  /** The id of the main content region, without the hash. */
  targetId?: string
  children: React.ReactNode
}

const CLASS = "vw-skip-link"

const CSS = `
.${CLASS} {
  position: absolute;
  left: -9999px;
  top: 0;
  z-index: 100;
  padding: 0.75rem 1rem;
  background: var(--vw-color-surface);
  color: var(--vw-color-text);
  border-radius: var(--vw-radius-md);
}
.${CLASS}:focus {
  left: 1rem;
  top: 1rem;
  outline: 3px solid var(--vw-color-focus);
  outline-offset: 2px;
}
`

export function SkipLink({ targetId = "main", children }: SkipLinkProps): React.ReactElement {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />
      <a className={CLASS} href={`#${targetId}`}>
        {children}
      </a>
    </>
  )
}
