/**
 * The theme token contract.
 *
 * This type mirrors `theme.json` in `@vewao/config-schema`, which is where the
 * tokens are validated — including the WCAG AA contrast check that fails a
 * build rather than a review. The kit's job is the other half: turning a
 * validated token set into CSS custom properties that every component in the
 * kit reads from.
 *
 * A component that hardcodes a colour instead of reading a token is a component
 * that will look wrong in twenty-nine shops.
 */

export type ThemeColors = {
  background: string
  surface: string
  text: string
  textMuted: string
  primary: string
  onPrimary: string
  border: string
  focus: string
  danger: string
  onDanger: string
  success: string
  onSuccess: string
}

export type Theme = {
  schemaVersion: 1
  color: ThemeColors
  font: {
    body: string
    heading: string
    baseSizePx?: number
    scale?: number
  }
  radius?: { sm?: string; md?: string; lg?: string }
  spacing?: { unitPx?: number; containerMaxPx?: number }
  logo?: { src: string; alt: string; widthPx?: number; heightPx?: number }
}

const PREFIX = "--vw"

function kebab(name: string): string {
  return name.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)
}

/**
 * Flatten a theme into CSS custom properties.
 *
 * Custom properties rather than a build-time transform, deliberately: the kit
 * ships as source and is compiled by each client's Next build, so a token that
 * baked itself into a class name at kit-build time would be the same in every
 * shop. Properties are resolved by the browser, per shop, from one declaration.
 */
export function themeToCssProperties(theme: Theme): Record<string, string> {
  const properties: Record<string, string> = {}

  for (const [name, value] of Object.entries(theme.color)) {
    properties[`${PREFIX}-color-${kebab(name)}`] = value
  }

  properties[`${PREFIX}-font-body`] = theme.font.body
  properties[`${PREFIX}-font-heading`] = theme.font.heading
  properties[`${PREFIX}-font-size-base`] = `${theme.font.baseSizePx ?? 16}px`
  properties[`${PREFIX}-font-scale`] = String(theme.font.scale ?? 1.25)

  properties[`${PREFIX}-radius-sm`] = theme.radius?.sm ?? "2px"
  properties[`${PREFIX}-radius-md`] = theme.radius?.md ?? "6px"
  properties[`${PREFIX}-radius-lg`] = theme.radius?.lg ?? "12px"

  properties[`${PREFIX}-space-unit`] = `${theme.spacing?.unitPx ?? 4}px`
  properties[`${PREFIX}-container-max`] = `${theme.spacing?.containerMaxPx ?? 1280}px`

  return properties
}

/** The `:root` block a client storefront renders once, in its root layout. */
export function themeToCss(theme: Theme, selector = ":root"): string {
  const properties = themeToCssProperties(theme)
  const body = Object.entries(properties)
    .map(([name, value]) => `  ${name}: ${value};`)
    .join("\n")
  return `${selector} {\n${body}\n}`
}

/** Read a token in component code, so nothing hardcodes a colour. */
export function token(name: string): string {
  return `var(${PREFIX}-${name})`
}
