/**
 * Money and dates, formatted for Czech shoppers.
 *
 * The rule that matters: **Medusa v2 amounts are decimal, not minor units.**
 * 49.99 is 49.99 Kč. Dividing by 100 here is the single most common storefront
 * bug against v2 and it is silent — the page renders, the number is simply
 * wrong by two orders of magnitude. Payment providers that want haléře convert
 * on their own side, where the requirement actually lives.
 */

export type MoneyInput = {
  amount: number
  currencyCode: string
  locale?: string
}

export function formatMoney({ amount, currencyCode, locale = "cs-CZ" }: MoneyInput): string {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: currencyCode.toUpperCase(),
    // Czech convention rounds to whole crowns for display; other currencies
    // keep their usual two.
    maximumFractionDigits: currencyCode.toLowerCase() === "czk" ? 0 : 2,
  }).format(amount)
}

export function formatDate(value: Date | string, locale = "cs-CZ"): string {
  const date = value instanceof Date ? value : new Date(value)
  return new Intl.DateTimeFormat(locale, { dateStyle: "long" }).format(date)
}

/**
 * The percentage a customer sees on a discount badge, rounded the way a shopper
 * reads it — down, so "30 % off" is never an overstatement. Overstating a
 * discount is exactly what the Omnibus rules exist to prevent.
 */
export function discountPercentage(from: number, to: number): number {
  if (!(from > 0) || to >= from) return 0
  return Math.floor(((from - to) / from) * 100)
}
