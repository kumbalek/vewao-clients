/**
 * Which payment methods a shopper may choose, and how each one behaves.
 *
 * Two things are generalised here from the legacy shop, where both were
 * hardcoded in the storefront:
 *
 * 1. **The provider registry.** A map from Medusa's `provider_id` to a title,
 *    a behaviour, and whether it needs a redirect. The legacy version carried
 *    iDeal and Bancontact entries for a Czech herbal shop, which is what a
 *    copied starter looks like a year later.
 *
 * 2. **The rule that some payment methods only apply to some shipping
 *    options.** The legacy expression was `activeShippingPrice !== 0`, meaning
 *    "pay in person only when collecting in person". That intent is worth
 *    keeping and worth stating; the arithmetic was not.
 */

export type PaymentBehaviour =
  /** The provider hands back a URL and the shopper leaves the site to pay. */
  | "redirect"
  /** Card details are captured in-page by the provider's own element. */
  | "embedded"
  /** Nothing to collect at checkout: dobírka, bank transfer, pay on collection. */
  | "deferred"

export type PaymentProviderInfo = {
  /** Matched against the start of Medusa's provider_id. */
  idPrefix: string
  behaviour: PaymentBehaviour
  /** Message key, not a label. Copy lives in the client's translations. */
  titleKey: string
  /**
   * True when the shopper has not paid by the time the order is placed, so the
   * order needs a payment-pending state and the confirmation email must say so.
   */
  settlesLater: boolean
  /** Requires the shopper to be physically present, e.g. paying on collection. */
  requiresPresence?: boolean
}

export const PAYMENT_PROVIDERS: PaymentProviderInfo[] = [
  { idPrefix: "pp_comgate_", behaviour: "redirect", titleKey: "payment.comgate", settlesLater: false },
  { idPrefix: "pp_stripe_", behaviour: "embedded", titleKey: "payment.card", settlesLater: false },
  { idPrefix: "pp_gopay_", behaviour: "redirect", titleKey: "payment.gopay", settlesLater: false },
  { idPrefix: "pp_cod_", behaviour: "deferred", titleKey: "payment.cod", settlesLater: true },
  { idPrefix: "pp_bank_transfer_", behaviour: "deferred", titleKey: "payment.bankTransfer", settlesLater: true },
  {
    idPrefix: "pp_system_default",
    behaviour: "deferred",
    titleKey: "payment.onCollection",
    settlesLater: true,
    requiresPresence: true,
  },
]

export function providerInfo(providerId: string | undefined): PaymentProviderInfo | undefined {
  if (!providerId) return undefined
  return PAYMENT_PROVIDERS.find((p) => providerId.startsWith(p.idPrefix))
}

export function isRedirectProvider(providerId: string | undefined): boolean {
  return providerInfo(providerId)?.behaviour === "redirect"
}

export type ShippingContext = {
  /** The chosen shipping option, if any. */
  optionId?: string
  /** True when the shopper collects the order in person. */
  isPickupInPerson: boolean
}

/**
 * Filter the providers Medusa offers down to the ones that make sense for the
 * chosen shipping option.
 *
 * A method requiring the shopper's presence — paying at the counter — is only
 * available when they are going to be present. Everything else stays: a shop
 * that wants to restrict dobírka to certain carriers expresses that as a
 * shipping-option rule in the backend, not as a hidden condition in a
 * storefront, because a hidden storefront condition is invisible to the
 * merchant who has to explain it to a customer.
 */
export function availablePaymentProviders<T extends { id: string }>(
  providers: T[],
  shipping: ShippingContext
): T[] {
  return providers.filter((provider) => {
    const info = providerInfo(provider.id)
    if (!info) return true
    if (info.requiresPresence) return shipping.isPickupInPerson
    return true
  })
}
