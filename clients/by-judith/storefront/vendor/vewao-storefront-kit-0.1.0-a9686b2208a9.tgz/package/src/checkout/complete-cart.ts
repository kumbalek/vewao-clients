/**
 * Completing a cart, including the redirect-based providers Czech shops
 * actually use.
 *
 * The legacy storefront had this logic inline in a server action, reading
 * `comgate_redirect_url` out of the payment session by name. Generalised here:
 * a provider that needs the shopper to leave the site says so through its
 * session data, and this returns an instruction rather than performing the
 * navigation.
 *
 * **Why an instruction and not a `redirect()`:** the kit stays framework-plain
 * and therefore testable. Next's `redirect` throws a control-flow exception,
 * which inside a try/catch here would be caught and reported as a failed
 * checkout — a real and well-known way to lose orders. The caller performs the
 * navigation at the top level of its action, where that cannot happen.
 */

export type CartCompletionResult =
  | { type: "order"; orderId: string }
  | { type: "redirect"; url: string }
  | { type: "error"; message: string }

/** The keys providers use for "send the shopper here to pay". */
const REDIRECT_KEYS = ["redirect_url", "comgate_redirect_url", "gateway_url", "payment_url"] as const

export function findRedirectUrl(sessionData: Record<string, unknown> | undefined | null): string | undefined {
  if (!sessionData) return undefined
  for (const key of REDIRECT_KEYS) {
    const value = sessionData[key]
    if (typeof value === "string" && value.length > 0) return value
  }
  return undefined
}

type PaymentSessionLike = {
  provider_id?: string
  data?: Record<string, unknown> | null
}

type CartLike = {
  payment_collection?: { payment_sessions?: PaymentSessionLike[] | null } | null
}

/**
 * Decide where the shopper goes next, before `cart.complete` is called.
 *
 * A redirect provider is answered here rather than after completion: the order
 * is created by the provider's callback once payment succeeds, and completing
 * the cart first would produce an order that has not been paid for.
 */
export function nextStepBeforeCompletion(cart: CartLike): CartCompletionResult | undefined {
  const sessions = cart.payment_collection?.payment_sessions ?? []
  for (const session of sessions) {
    const url = findRedirectUrl(session.data ?? undefined)
    if (url) return { type: "redirect", url }
  }
  return undefined
}

type CompleteCartResponse = {
  type: "order" | "cart"
  order?: { id: string }
  error?: { message?: string }
}

type CompleteCartDeps = {
  /** `sdk.store.cart.complete` — passed in so this is testable without a server. */
  complete: (cartId: string) => Promise<CompleteCartResponse>
  retrieve: (cartId: string) => Promise<CartLike>
}

export async function completeCart(cartId: string, deps: CompleteCartDeps): Promise<CartCompletionResult> {
  const cart = await deps.retrieve(cartId)

  const redirect = nextStepBeforeCompletion(cart)
  if (redirect) return redirect

  const response = await deps.complete(cartId)

  if (response.type === "order" && response.order?.id) {
    return { type: "order", orderId: response.order.id }
  }

  return {
    type: "error",
    message: response.error?.message ?? "The order could not be completed. No payment has been taken.",
  }
}
